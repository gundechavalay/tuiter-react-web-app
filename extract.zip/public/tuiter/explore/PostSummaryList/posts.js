export default [
    {
        topic: 'Web Development',
        userName: 'ReactJS',
        time: '2h',
        title: 'React.js is a component based front end library that makes it very easy to build Single Page Applications or SPAs',
        image: 'images/react.jpg'
    },
    {
        topic: '',
        userName: 'Relativity',
        time: '1 day',
        title: 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
        image: 'images/relativity.jpg',
        tweets: '123K',
    },
    {
        topic: '',
        userName: 'Tesla',
        title: 'Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit',
        time: 'last week',
        image: 'images/tesla.jpg',
        tweets: '122K',
    },];
 