export default [
  {   avatarIcon: 'images/java.png',
    userName: 'Java', handle: 'Java', },
  {   avatarIcon: 'images/relativity.jpg',
    userName: 'Relativity Space',
    handle: 'relativityspace', },
  {   avatarIcon: 'images/virgin.jpg',
    userName: 'Virgin Galactic',
    handle: 'virgingalactic', },
  {   avatarIcon: 'images/nasa.jpg',
    userName: 'NASA', handle: 'NASA', },
  {   avatarIcon: 'images/tesla.jpg',
    userName: 'Tesla', handle: 'Tesla', }, ];