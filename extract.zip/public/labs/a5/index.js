// alert('Hello World!');
console.log('Hello World!');
console.log('Variables and Constants');
var global1 = 10;
var functionScoped = 2;
let blockScoped = 5;
const constant1 = global1
                  + functionScoped
                  - blockScoped;